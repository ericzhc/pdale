/*
**********************************************************************
*                          Micrium, Inc.
*                      949 Crestview Circle
*                     Weston,  FL 33327-1848
*
*                            uC/FS
*
*             (c) Copyright 2001 - 2003, Micrium, Inc.
*                      All rights reserved.
*
***********************************************************************

----------------------------------------------------------------------
File        : api_int.h 
Purpose     : Internals used accross different modules of API layer
---------------------------END-OF-HEADER------------------------------
*/

#ifndef _FS_API_INT_H_
#define _FS_API_INT_H_

#if defined(__cplusplus)
extern "C" {     /* Make sure we have C-declarations in C++ programs */
#endif

/*********************************************************************
*
*             Global function prototypes
*
**********************************************************************
*/

FS_VOLUME * FS_FindVolume(const char *pFullName, FS_FARCHARPTR *pFileName);

#if defined(__cplusplus)
  }              /* Make sure we have C-declarations in C++ programs */
#endif

#endif  /* _FS_API_INT_H_ */

/*************************** End of file ****************************/
